package com.example.notification.kafka;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;

public interface IBrokerChannel {

    @Input("energy_intensity")
    SubscribableChannel energy_intensity();
    @Input("crude_quality")
    SubscribableChannel crude_quality();
    @Input("flare_monitor")
    SubscribableChannel flare_monitor();
}
