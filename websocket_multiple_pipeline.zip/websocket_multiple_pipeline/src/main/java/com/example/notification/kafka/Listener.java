package com.example.notification.kafka;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;

@Component
public class Listener {

    @Autowired
    private SimpMessagingTemplate template;

    @StreamListener(target = "energy_intensity")
    public void processMessageEnertyIntensity(String pushMessage){
    	System.out.println(pushMessage.toString());
    	
    	try {
        JSONObject jsonObject = new JSONObject(pushMessage);
        
        JSONObject getSth = jsonObject.getJSONObject("payload");
        Object level = getSth.get("after");
        
        System.out.println(">>>> Energy Intensity >>>>>>  "+level.toString());
        this.template.convertAndSend("/topic/energy_intensity", level.toString());
        
    	}catch(Exception ex) {ex.printStackTrace();}
    	
    }
    
    @StreamListener(target = "crude_quality")
    public void processMessageCrudeQuality(String pushMessage){
    	System.out.println(pushMessage.toString());
    	
    	try {
        JSONObject jsonObject = new JSONObject(pushMessage);
        
        JSONObject getSth = jsonObject.getJSONObject("payload");
        Object level = getSth.get("after");
        
        System.out.println(">>>>> Crude Quality >>>>>  "+level.toString());
        this.template.convertAndSend("/topic/crude_quality", level.toString());
        
    	}catch(Exception ex) {ex.printStackTrace();}
    	
    }
    
    @StreamListener(target = "flare_monitor")
    public void processMessageFlareMonitor(String pushMessage){
    	System.out.println(pushMessage.toString());
    	
    	try {
        JSONObject jsonObject = new JSONObject(pushMessage);
        
        JSONObject getSth = jsonObject.getJSONObject("payload");
        Object level = getSth.get("after");
        
        System.out.println(">>>>> Flare Monitor >>>>>  "+level.toString());
        this.template.convertAndSend("/topic/flare_monitor", level.toString());
        
    	}catch(Exception ex) {ex.printStackTrace();}
    	
    }
    
	/*public List<String> getValuesForGivenKey(String jsonArrayStr, String key) {
	    JSONArray jsonArray = new JSONArray(jsonArrayStr);
	    return IntStream.range(0, jsonArray.length())
	      .mapToObj(index -> ((JSONObject)jsonArray.get(index)).optString(key))
	      .collect(Collectors.toList());
	}*/
    
}
