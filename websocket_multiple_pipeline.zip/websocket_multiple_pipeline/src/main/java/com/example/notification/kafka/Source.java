package com.example.notification.kafka;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"version",
"connector",
"name",
"ts_ms",
"snapshot",
"db",
"schema",
"table",
"change_lsn",
"commit_lsn",
"event_serial_no"
})
public class Source {

@JsonProperty("version")
private String version;
@JsonProperty("connector")
private String connector;
@JsonProperty("name")
private String name;
@JsonProperty("ts_ms")
private Integer ts_ms;
@JsonProperty("snapshot")
private String snapshot;
@JsonProperty("db")
private String db;
@JsonProperty("schema")
private String schema;
@JsonProperty("table")
private String table;
@JsonProperty("change_lsn")
private String change_lsn;
@JsonProperty("commit_lsn")
private String commit_lsn;
@JsonProperty("event_serial_no")
private Integer event_serial_no;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("version")
public String getVersion() {
return version;
}

@JsonProperty("version")
public void setVersion(String version) {
this.version = version;
}

public Source withVersion(String version) {
this.version = version;
return this;
}

@JsonProperty("connector")
public String getConnector() {
return connector;
}

@JsonProperty("connector")
public void setConnector(String connector) {
this.connector = connector;
}

public Source withConnector(String connector) {
this.connector = connector;
return this;
}

@JsonProperty("name")
public String getName() {
return name;
}

@JsonProperty("name")
public void setName(String name) {
this.name = name;
}

public Source withName(String name) {
this.name = name;
return this;
}

@JsonProperty("ts_ms")
public Integer getTs_ms() {
return ts_ms;
}

@JsonProperty("ts_ms")
public void setTs_ms(Integer ts_ms) {
this.ts_ms = ts_ms;
}

public Source withTs_ms(Integer ts_ms) {
this.ts_ms = ts_ms;
return this;
}

@JsonProperty("snapshot")
public String getSnapshot() {
return snapshot;
}

@JsonProperty("snapshot")
public void setSnapshot(String snapshot) {
this.snapshot = snapshot;
}

public Source withSnapshot(String snapshot) {
this.snapshot = snapshot;
return this;
}

@JsonProperty("db")
public String getDb() {
return db;
}

@JsonProperty("db")
public void setDb(String db) {
this.db = db;
}

public Source withDb(String db) {
this.db = db;
return this;
}

@JsonProperty("schema")
public String getSchema() {
return schema;
}

@JsonProperty("schema")
public void setSchema(String schema) {
this.schema = schema;
}

public Source withSchema(String schema) {
this.schema = schema;
return this;
}

@JsonProperty("table")
public String getTable() {
return table;
}

@JsonProperty("table")
public void setTable(String table) {
this.table = table;
}

public Source withTable(String table) {
this.table = table;
return this;
}

@JsonProperty("change_lsn")
public String getChange_lsn() {
return change_lsn;
}

@JsonProperty("change_lsn")
public void setChange_lsn(String change_lsn) {
this.change_lsn = change_lsn;
}

public Source withChange_lsn(String change_lsn) {
this.change_lsn = change_lsn;
return this;
}

@JsonProperty("commit_lsn")
public String getCommit_lsn() {
return commit_lsn;
}

@JsonProperty("commit_lsn")
public void setCommit_lsn(String commit_lsn) {
this.commit_lsn = commit_lsn;
}

public Source withCommit_lsn(String commit_lsn) {
this.commit_lsn = commit_lsn;
return this;
}

@JsonProperty("event_serial_no")
public Integer getEvent_serial_no() {
return event_serial_no;
}

@JsonProperty("event_serial_no")
public void setEvent_serial_no(Integer event_serial_no) {
this.event_serial_no = event_serial_no;
}

public Source withEvent_serial_no(Integer event_serial_no) {
this.event_serial_no = event_serial_no;
return this;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

public Source withAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
return this;
}

@Override
public String toString() {
return new ToStringBuilder(this).append("version", version).append("connector", connector).append("name", name).append("ts_ms", ts_ms).append("snapshot", snapshot).append("db", db).append("schema", schema).append("table", table).append("change_lsn", change_lsn).append("commit_lsn", commit_lsn).append("event_serial_no", event_serial_no).append("additionalProperties", additionalProperties).toString();
}

}
