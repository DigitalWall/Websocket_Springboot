package com.example.notification.kafka;

public class Message {
	
	private String corp_energy_id;
	private int corp_energy_val;
	
	private String op;
	private String ts_ms;
	public String getCorp_energy_id() {
		return corp_energy_id;
	}
	public void setCorp_energy_id(String corp_energy_id) {
		this.corp_energy_id = corp_energy_id;
	}
	public int getCorp_energy_val() {
		return corp_energy_val;
	}
	public void setCorp_energy_val(int corp_energy_val) {
		this.corp_energy_val = corp_energy_val;
	}
	public String getOp() {
		return op;
	}
	public void setOp(String op) {
		this.op = op;
	}
	public String getTs_ms() {
		return ts_ms;
	}
	public void setTs_ms(String ts_ms) {
		this.ts_ms = ts_ms;
	}
	@Override
	public String toString() {
		return "Message [corp_energy_id=" + corp_energy_id + ", corp_energy_val=" + corp_energy_val + ", op=" + op
				+ ", ts_ms=" + ts_ms + "]";
	}
	
	
	

    /*private String firstName;
    private String lastName;

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {

        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
*/}
